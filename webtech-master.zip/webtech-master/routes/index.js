const router = require('express').Router();

const students = [
    {
        name: "Frank Martin",
        DOB: "03/01/2001",
        program: "BSC Computer science",
        level: "200",
        image:"/images/frankmartin.jpg"
    },
    {
        name: "Mark Iwe",
        DOB: "23/04/1998",
        program: "BSC Law",
        level: "400",
        image:"/images/markiwe.jpg"
    },
    {
        name: "Chekwas Mary",
        DOB: "06/03/1987",
        program: "BSC ICT",
        level: "300",
        image :"/images/chekwas mary.jpg"
    },
    {
        name: "Sam Jay",
        DOB: "09/12/1997",
        program: "BSC Business",
        level: "300",
        image:"/images/samjay.jpg"
    },
    {
        name: "Jude Ike",
        DOB: "12/20/2000",
        program: "BSC Medlab",
        level: "100",
        image:"/images/judeike.jpg"
    }
]


router.get('/', (req, res)=>{
    res.render('home', {
        title:'Home',
        students
    })
});

router.get('/student/:id', (req, res)=>{
    const id = req.params.id;
    const student = students[id];
    res.render('student', {
        title: students[id].name,
        student
    })
});

module.exports = router;