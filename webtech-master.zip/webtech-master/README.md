This is a sample solution to the asignment you have been give for
your Web Tech course
You are not to copy and present this as your own work, that would be
considered as plegiarism
It is therefore to serve as your guide to developing your own unique version

### Clone or download the full project and open it in your VSCODE text editor

### The project has been properly structured into meaningful folders so you can understand
*node_modules
*public
*routes
*views
*app.js
*package-lock.json
*package.json

### In the Package.json file
We have all the necessary dependencies installed including
'ejs', 'express', 'bootstrap4', 'jquery'

### routes/index.js
In the routes folder is an index.js file that includes the static students details in array of objects. That is the data you see populated on your browser.

When you click view more it fetches all the details of the student and opens another page to display the contents.